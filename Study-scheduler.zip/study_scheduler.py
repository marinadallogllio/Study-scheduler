import re
import random

def main():
    subjects, importances = get_subjects()
    hours, totalblocks = get_hours()
    blockspersubject = blocks_forsubjects(importances, totalblocks)
    blocks_week = schedule_organizer(blockspersubject, subjects)
    schedule = arranging_subjects(hours, blocks_week)
    print(schedule)

def get_subjects():
    print("Informe as disciplinas que você quer estudar neste semestre")
    print("e a importância relativa de cada uma (1-5). Pressione Control+D quando terminar.")
    subjects = []
    importances = []
    try:
        while True:
            subject = input("Disciplina: ").strip()
            try:
                importance = int(input("Importância (1-5): ").strip())
                if importance < 1 or importance > 5:
                    print("Erro: a importância deve estar entre 1 e 5")
                    continue
            except ValueError:
                print("Entrada inválida: digite um número inteiro")
                continue
            subjects.append(subject)
            importances.append(importance)
    except EOFError:
        return subjects, importances

def get_hours(user_input=None):
    print("\nAgora informe os horários em que você estudará por dia.")
    print("Podem ser vários blocos, mas todos com a MESMA duração.")
    print("Exemplo: 10:00-12:00 and 16:30-18:30")
    if user_input is None:
        user_input = input("Quais horários você quer estudar a cada dia? ").strip()

    hours = [h.strip() for h in user_input.split(" and ") if h.strip()]
    if not hours:
        raise ValueError("Nenhum bloco de horário informado.")

    # Simples escala de capacidade semanal: nº de blocos por dia * 5 dias úteis
    total_blocks = len(hours) * 5

    pattern = r"^(\d{1,2}):(\d{2})-(\d{1,2}):(\d{2})$"
    for block in hours:
        if not re.match(pattern, block):
            raise ValueError(f"Formato de horário inválido: {block}")
    return hours, total_blocks

def blocks_forsubjects(importances, totalblocks):
    total_importance = sum(importances)
    if total_importance == 0:
        return [0] * len(importances)
    subjects_blocks = [round(totalblocks * (imp / total_importance)) for imp in importances]

    # Ajuste fino para bater o total
    difference = totalblocks - sum(subjects_blocks)
    i = 0
    while difference != 0 and len(subjects_blocks) > 0:
        idx = i % len(subjects_blocks)
        if difference > 0:
            subjects_blocks[idx] += 1
            difference -= 1
        elif difference < 0 and subjects_blocks[idx] > 0:
            subjects_blocks[idx] -= 1
            difference += 1
        i += 1
    return subjects_blocks

def schedule_organizer(subjects_blocks, subjects):
    blocks_week = []
    for i, subject in enumerate(subjects):
        blocks_week.extend([subject] * subjects_blocks[i])
    random.shuffle(blocks_week)
    return blocks_week

def arranging_subjects(daily_blocks, blocks_week):
    weekdays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
    schedule = {day: [] for day in weekdays}
    index = 0
    for day in weekdays:
        for block in daily_blocks:
            if index >= len(blocks_week):
                break
            subject = blocks_week[index]
            schedule[day].append((block, subject))
            index += 1
    return schedule

if __name__ == "__main__":
    main()