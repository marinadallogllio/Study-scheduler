# Study-scheduler

CLI em Python para criar um **cronograma semanal de estudos** baseado em prioridades.

## ✨ O que faz
- Você informa *disciplinas* e sua **importância (1–5)**
- Define **blocos diários** de estudo (ex.: `10:00-12:00 and 16:30-18:30`)
- O programa **distribui os blocos proporcionalmente** à importância e embaralha a semana para variar

## ▶️ Como executar
```bash
python study_scheduler.py
```

### Exemplo
```
Disciplina: Cálculo
Importância (1-5): 5
Disciplina: Python
Importância (1-5): 4
Disciplina: História
Importância (1-5): 2
^D

Quais horários você quer estudar a cada dia? 10:00-12:00 and 16:30-18:30
```

**Saída (exemplo resumido):**
```python
{
  "Monday":   [("10:00-12:00", "Cálculo"), ("16:30-18:30", "Python")],
  "Tuesday":  [("10:00-12:00", "Cálculo"), ("16:30-18:30", "História")],
  "Wednesday":[("10:00-12:00", "Python"),  ("16:30-18:30", "Cálculo")],
  "Thursday": [("10:00-12:00", "Cálculo"), ("16:30-18:30", "Python")],
  "Friday":   [("10:00-12:00", "História"),("16:30-18:30", "Cálculo")]
}
```

> ℹ️ A capacidade semanal é `nº de blocos por dia × 5`. Altere para 7 se quiser incluir fins de semana.

## 🧩 Personalizações rápidas
- Edite `weekdays` em `arranging_subjects` para 7 dias
- Troque `round` por `floor/ceil` para ajustar viés de alocação
- Remova `random.shuffle` se preferir ordem fixa

## 📄 Apresentar no LinkedIn
- **Link:** publique este repositório como público e cole o link no post
- **PDF:** abra `index.html` no navegador e use **Imprimir → Salvar como PDF**

---
MIT License